#Werewolf for Telegram

This will be the home for Werewolf Moderator in the future.  For now, let me get the code in place :)

For language file updates, please submit the xml file on Telegram to the [support chat](http://telegram.me/werewolfsupport) and ping @Para949
