﻿namespace Telegram.Bot.Types.ReplyMarkups
{
    public interface IReplyMarkup
    {
    }
}
